//app.js

App({
    onLaunch: function () {
        var z = this
    },
    globalData: {
    }
})