Page({
  onShareAppMessage() {
    return {
      title: '联系客服',
      path: 'packageAPI/pages/custom-service/custom-service'
    }
  },
})
