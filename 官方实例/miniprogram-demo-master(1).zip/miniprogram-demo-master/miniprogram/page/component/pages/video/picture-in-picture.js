Page({
  data: {
  },
  onLoad(options) {

  },
  onReady() {

  },
  onShareAppMessage() {
    return {
      title: '小窗模式',
      path: 'page/component/pages/picture-in-picture/picture-in-picture'
    }
  },
  // onShareAppMessage() {
  //   return {
  //     title: 'video',
  //     path: 'page/component/pages/video/video'
  //   }
  // },
});

