

Component({
  options: {
    addGlobalClass: true
  },
  properties: {
    extClass: {
      type: String,
      value: ''
    },
    content: {
      type: String,
      value: ''
    }
  }
})
