import CustomPage from '../../base/CustomPage'

CustomPage({
  onShareAppMessage() {
    return {
      title: 'flex',
      path: 'page/weui/example/flex/flex'
    }
  },
})