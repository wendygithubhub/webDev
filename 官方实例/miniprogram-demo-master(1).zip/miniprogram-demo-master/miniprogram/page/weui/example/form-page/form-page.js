Component({
    onShareAppMessage() {
        return {
          title: 'form-age',
          path: 'page/weui/example/form-age/form-age'
        }
      },
    data: {},
    methods: {}
});