Page({
  onShareAppMessage() {
    return {
      title: 'slider',
      path: 'page/weui/example/slider/slider'
    }
  },
});