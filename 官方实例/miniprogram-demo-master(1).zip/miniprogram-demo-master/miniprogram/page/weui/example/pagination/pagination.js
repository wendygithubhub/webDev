Page({
  data: {},
  onLoad() {},
  onShareAppMessage() {
    return {
      title: '分页展现',
      path: 'page/weui/example/pagination/pagination'
    }
  },
})